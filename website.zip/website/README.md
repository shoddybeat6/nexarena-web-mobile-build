# NexArena Website

Multi-page site (HTML, CSS, JavaScript) for NexArena Gaming & Esports Arena.

```
nexarena-website/
  index.html            Home
  about.html            About us
  packages.html         Packages (overview)
  package-details.html  Individual package (?id=vip)
  fees.html             Calculate fees & checkout
  contact.html          Contact us
  css/style.css         Styles + palette variables
  js/script.js          Package data, fee calculator, details page
  images/logo.png       NexArena logo
```

Open `index.html` in a browser, or use the VS Code Live Server extension.
