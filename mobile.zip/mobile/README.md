# NexArena Mobile App

Multi-screen mobile app prototype (HTML, CSS, JavaScript) for NexArena. On desktop it shows a phone frame; on a phone it fills the screen.

```
nexarena-mobile-app/
  index.html            Home
  packages.html         Packages (overview)
  package-details.html  Individual package (?id=vip)
  fees.html             Calculate fees & checkout
  about.html            About us
  contact.html          Contact us
  css/style.css         Styles + palette variables
  js/script.js          Package data, fee calculator, details screen
  images/logo-icon.png  NexArena logo icon
```

Open `index.html` in a browser, or use the VS Code Live Server extension.
